CREATE DATABASE IF NOT EXISTS kmu_asset
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE kmu_asset;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin', 'pimpinan') NOT NULL DEFAULT 'pimpinan',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

SET @role_column_exists = (
  SELECT COUNT(*)
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'users'
    AND column_name = 'role'
);
SET @role_migration = IF(
  @role_column_exists = 0,
  'ALTER TABLE users ADD COLUMN role ENUM(''admin'', ''pimpinan'') NOT NULL DEFAULT ''pimpinan'' AFTER password_hash',
  'SELECT 1'
);
PREPARE role_migration_statement FROM @role_migration;
EXECUTE role_migration_statement;
DEALLOCATE PREPARE role_migration_statement;

SET @legacy_admin_migration = IF(
  @role_column_exists = 0,
  'UPDATE users SET role = ''admin'' ORDER BY id ASC LIMIT 1',
  'SELECT 1'
);
PREPARE legacy_admin_statement FROM @legacy_admin_migration;
EXECUTE legacy_admin_statement;
DEALLOCATE PREPARE legacy_admin_statement;

ALTER TABLE users MODIFY role ENUM('admin', 'user', 'pimpinan') NOT NULL DEFAULT 'pimpinan';
UPDATE users SET role = 'pimpinan' WHERE role = 'user';
ALTER TABLE users MODIFY role ENUM('admin', 'pimpinan') NOT NULL DEFAULT 'pimpinan';

CREATE TABLE IF NOT EXISTS assets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  asset_code VARCHAR(40) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  category VARCHAR(80) NOT NULL,
  location VARCHAR(120) NOT NULL,
  asset_condition ENUM('Baik', 'Perlu servis', 'Rusak') NOT NULL DEFAULT 'Baik',
  purchase_date DATE NULL,
  warranty_until DATE NULL,
  service_due DATE NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT IGNORE INTO assets
  (asset_code, name, category, location, asset_condition, purchase_date, warranty_until, service_due)
VALUES
  ('KMU-IT-001', 'Laptop Lenovo ThinkPad', 'IT & Elektronik', 'Kantor Pusat - Finance', 'Baik', '2025-02-12', '2027-02-12', '2026-11-15'),
  ('KMU-OPS-014', 'Printer Epson L3210', 'Peralatan Kantor', 'Kantor Pusat - Umum', 'Perlu servis', '2023-08-20', '2026-10-30', '2026-10-20'),
  ('KMU-OPS-021', 'AC Daikin 2 PK', 'Elektronik', 'Kantor Pusat - Meeting Room', 'Baik', '2024-06-05', '2026-11-08', '2026-10-28');