# KMU Asset

Aplikasi PHP native + MySQL untuk login, pendaftaran akun, role, dan pengelolaan aset.

## Menjalankan di XAMPP

1. Simpan folder proyek ini di dalam `C:\xampp\htdocs`. Nama folder boleh diganti.
2. Buka XAMPP Control Panel, lalu jalankan **Apache** dan **MySQL**.
3. Buka `http://localhost/phpmyadmin`.
4. Pilih tab **Import**, pilih file `database.sql` dari folder proyek, lalu tekan **Import**.
5. Buka `http://localhost/<nama-folder>/`, dengan `<nama-folder>` sesuai nama folder proyek, misalnya `http://localhost/Ujian%20CBA%20Hadi/`.
6. Sebelum aplikasi digunakan publik, operator tepercaya membuka **Daftar** dan membuat akun pertama. Akun pertama otomatis menjadi Admin. Pendaftaran berikutnya otomatis menjadi Pimpinan Aset. Setelah daftar, login menggunakan email dan password; role dibaca dari database.

Konfigurasi database bawaan: host `127.0.0.1`, database `kmu_asset`, pengguna `root`, dan kata sandi kosong. Jika instalasi berbeda, ubah `config.php`.

`database.sql` membuat tabel yang diperlukan, menambahkan kolom role bila database lama belum memilikinya, dan mempertahankan data aset contoh. Jika database lama belum memiliki akun admin, pengguna pertama akan diberi role admin.

## Login, register, dan role akun

- **Admin**: hanya dibuat otomatis untuk akun pertama saat database belum memiliki akun; dapat melihat, menambah, mengedit, dan menghapus aset.
- **Pimpinan Aset**: semua akun yang mendaftar setelah Admin pertama; hanya dapat melihat daftar aset.

Login dan register memakai tampilan yang sama dengan tautan untuk berpindah. Saat login, aplikasi menemukan role berdasarkan email akun; pengguna tidak memilih role dan tidak dapat menaikkan hak akses dari formulir.