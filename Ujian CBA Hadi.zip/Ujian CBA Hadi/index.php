<?php
declare(strict_types=1);

session_start();
require __DIR__ . '/config.php';

try {
    $pdo = db();
    if (!$pdo->query("SHOW COLUMNS FROM users LIKE 'role'")->fetch()) {
        exit('Struktur database lama belum memiliki kolom role. Import ulang database.sql melalui phpMyAdmin.');
    }
    $userCount = $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
} catch (PDOException $error) {
    exit('Database belum siap. Pastikan MySQL aktif dan database.sql sudah diimpor.');
}

$sessionUserId = (int) ($_SESSION['user']['id'] ?? 0);
if ($sessionUserId > 0) {
    $query = $pdo->prepare('SELECT id, name, role FROM users WHERE id = ?');
    $query->execute([$sessionUserId]);
    $sessionUser = $query->fetch();
    if ($sessionUser) {
        $_SESSION['user'] = $sessionUser;
    } else {
        unset($_SESSION['user']);
    }
}

$message = '';
$isRegistered = !empty($_SESSION['registration_success']);
unset($_SESSION['registration_success']);
$isAdmin = ($_SESSION['user']['role'] ?? '') === 'admin';
$showRegister = (int) $userCount === 0
    || (($_GET['mode'] ?? $_GET['page'] ?? '') === 'register');

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!is_string($csrfToken) || !hash_equals($_SESSION['csrf_token'], $csrfToken)) {
        $message = 'Permintaan tidak valid. Silakan muat ulang halaman dan coba lagi.';
    } elseif ($action === 'register') {
        $name = trim((string) ($_POST['name'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');

        if ($name === '' || strlen($name) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150 || strlen($password) < 8) {
            $message = 'Isi nama dan email dengan benar. Password minimal 8 karakter.';
            $showRegister = true;
        } else {
            $lockResult = (int) $pdo->query("SELECT GET_LOCK('kmu_asset_registration', 10)")->fetchColumn();
            if ($lockResult !== 1) {
                $message = 'Pendaftaran sedang sibuk. Silakan coba kembali.';
                $showRegister = true;
            } else {
                try {
                    $userCount = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
                    $role = $userCount === 0 ? 'admin' : 'pimpinan';
                    $query = $pdo->prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
                    $query->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), $role]);
                } catch (PDOException $error) {
                    if ($error->getCode() !== '23000') {
                        throw $error;
                    }
                    $message = 'Email sudah terdaftar.';
                    $showRegister = true;
                } finally {
                    $pdo->query("SELECT RELEASE_LOCK('kmu_asset_registration')");
                }

                if ($message === '') {
                    $_SESSION['registration_success'] = true;
                    header('Location: index.php');
                    exit;
                }
            }
        }
    } elseif ($action === 'login') {
        $email = trim((string) ($_POST['email'] ?? ''));
        $user = null;
        $showRegister = false;
        $query = $pdo->prepare('SELECT id, name, password_hash, role FROM users WHERE email = ?');
        $query->execute([$email]);
        $user = $query->fetch();

        if ($user && password_verify((string) ($_POST['password'] ?? ''), $user['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => $user['id'], 'name' => $user['name'], 'role' => $user['role']];
            header('Location: index.php');
            exit;
        }
        $message = 'Email atau password salah.';
    } elseif ($action === 'logout') {
        $_SESSION = [];
        session_destroy();
        header('Location: index.php');
        exit;
    } elseif ($isAdmin && $action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $data = [
            (string) ($_POST['asset_code'] ?? ''),
            (string) ($_POST['name'] ?? ''),
            (string) ($_POST['category'] ?? ''),
            (string) ($_POST['location'] ?? ''),
            (string) ($_POST['asset_condition'] ?? ''),
        ];

        if ($id) {
            $query = $pdo->prepare('UPDATE assets SET asset_code=?, name=?, category=?, location=?, asset_condition=? WHERE id=?');
            $query->execute([...$data, $id]);
        } else {
            $query = $pdo->prepare('INSERT INTO assets (asset_code, name, category, location, asset_condition) VALUES (?, ?, ?, ?, ?)');
            $query->execute($data);
        }
        header('Location: index.php');
        exit;
    } elseif ($isAdmin && $action === 'delete') {
        $query = $pdo->prepare('DELETE FROM assets WHERE id = ?');
        $query->execute([(int) ($_POST['id'] ?? 0)]);
        header('Location: index.php');
        exit;
    }
}

$assets = [];
$edit = ['id' => '', 'asset_code' => '', 'name' => '', 'category' => '', 'location' => '', 'asset_condition' => 'Baik'];

if (!empty($_SESSION['user'])) {
    $assets = $pdo->query('SELECT * FROM assets ORDER BY id DESC')->fetchAll(PDO::FETCH_ASSOC);

    if ($isAdmin && isset($_GET['edit'])) {
        $query = $pdo->prepare('SELECT * FROM assets WHERE id = ?');
        $query->execute([(int) $_GET['edit']]);
        $edit = $query->fetch(PDO::FETCH_ASSOC) ?: $edit;
    }
}

function h($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>KMU Asset</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php if (empty($_SESSION['user'])): ?>
    <main class="login-box">
        <h1>KMU Asset</h1>
        <?php if ($showRegister && (int) $userCount === 0): ?><p>Buat akun Admin pertama</p><?php endif; ?>
        <?php if ($isRegistered): ?><p class="success">Pendaftaran berhasil. Silakan login dengan akun baru.</p><?php endif; ?>
        <?php if (!empty($message)): ?><p class="error"><?= h($message) ?></p><?php endif; ?>
        <?php if ((int) $userCount > 0): ?>
        <nav class="auth-tabs">
            <a class="<?= !$showRegister ? 'active' : '' ?>" href="index.php">Masuk akun</a>
            <a class="<?= $showRegister ? 'active' : '' ?>" href="index.php?mode=register">Buat akun</a>
        </nav>
        <?php endif; ?>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">
            <input type="hidden" name="action" value="<?= $showRegister ? 'register' : 'login' ?>">
            <?php if ($showRegister): ?>
                <label>Nama<input name="name" required></label>
            <?php endif; ?>
            <label>Email<input type="email" name="email" required></label>
            <label>Password<input type="password" name="password" minlength="8" required></label>
            <button type="submit"><?= $showRegister ? ((int) $userCount === 0 ? 'Buat akun Admin' : 'Daftar') : 'Login' ?></button>
        </form>
        <?php if ($showRegister): ?>
            <p class="role-note"><?= (int) $userCount === 0 ? 'Akun pertama otomatis menjadi Admin.' : 'Pendaftaran baru otomatis menjadi Pimpinan Aset.' ?></p>
        <?php endif; ?>
    </main>
<?php else: ?>
    <main class="dashboard">
        <header>
            <div><h1>Dashboard Aset</h1><p>Halo, <?= h($_SESSION['user']['name']) ?> - <?= $_SESSION['user']['role'] === 'admin' ? 'Admin' : 'Pimpinan Aset' ?></p></div>
            <form method="post"><input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>"><input type="hidden" name="action" value="logout"><button class="secondary">Keluar</button></form>
        </header>

        <section class="summary"><strong><?= count($assets) ?></strong><span>Total aset</span></section>

        <?php if ($isAdmin): ?>
        <section class="panel">
            <h2><?= $edit['id'] ? 'Edit aset' : 'Tambah aset' ?></h2>
            <form method="post" class="asset-form">
                <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="id" value="<?= h($edit['id']) ?>">
                <label>Kode aset<input name="asset_code" value="<?= h($edit['asset_code']) ?>" required></label>
                <label>Nama aset<input name="name" value="<?= h($edit['name']) ?>" required></label>
                <label>Kategori<input name="category" value="<?= h($edit['category']) ?>" required></label>
                <label>Lokasi<input name="location" value="<?= h($edit['location']) ?>" required></label>
                <label>Kondisi<select name="asset_condition">
                    <?php foreach (['Baik', 'Perlu servis', 'Rusak'] as $condition): ?>
                        <option <?= $edit['asset_condition'] === $condition ? 'selected' : '' ?>><?= h($condition) ?></option>
                    <?php endforeach; ?>
                </select></label>
                <button type="submit">Simpan</button>
            </form>
        </section>
        <?php endif; ?>

        <section class="panel">
            <h2>Daftar aset</h2>
            <div class="table-scroll"><table>
                <thead><tr><th>Kode</th><th>Nama</th><th>Kategori</th><th>Lokasi</th><th>Kondisi</th><?php if ($isAdmin): ?><th>Aksi</th><?php endif; ?></tr></thead>
                <tbody>
                <?php foreach ($assets as $asset): ?>
                    <tr>
                        <td><?= h($asset['asset_code']) ?></td><td><?= h($asset['name']) ?></td>
                        <td><?= h($asset['category']) ?></td><td><?= h($asset['location']) ?></td>
                        <td><?= h($asset['asset_condition']) ?></td>
                        <?php if ($isAdmin): ?><td class="actions"><a href="?edit=<?= (int) $asset['id'] ?>">Edit</a>
                            <form method="post" onsubmit="return confirm('Hapus aset ini?')">
                                <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= (int) $asset['id'] ?>">
                                <button class="delete" type="submit">Hapus</button>
                            </form>
                        </td><?php endif; ?>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$assets): ?><tr><td colspan="<?= $isAdmin ? 6 : 5 ?>">Belum ada data aset.</td></tr><?php endif; ?>
                </tbody>
            </table></div>
        </section>
    </main>
<?php endif; ?>
</body>
</html>